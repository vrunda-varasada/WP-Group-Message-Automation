import tkinter as tk
from tkinter import messagebox
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time
import os
import sys

# Function to read target names from groups.txt file
def read_targets(filename):
    script_dir = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, 'frozen', False) else __file__))
    filepath = os.path.join(script_dir, filename)
    with open(filepath, 'r', encoding='utf-8') as file:
        targets = [line.strip() for line in file.readlines() if line.strip()]
    return targets


# Function to send WhatsApp messages
def send_whatsapp_message():
    # Get message from text area
    message = text_area.get("1.0", tk.END).strip()
    if not message:
        messagebox.showwarning("Input Error", "Please enter a message")
        return
    
    # Initialize webdriver
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
    driver.get("https://web.whatsapp.com/")
    wait = WebDriverWait(driver, 60)

    # Read targets from groups.txt file
    targets = read_targets('groups.txt')

    # Loop through each target and send the message
    for target in targets:
        try:
            # Search for the target contact
            search_box_xpath = "//div[@contenteditable='true' and @data-tab='3']"
            search_box = wait.until(EC.presence_of_element_located((By.XPATH, search_box_xpath)))
            search_box.clear()
            search_box.send_keys(target)
            time.sleep(3)
            search_box.send_keys(Keys.ENTER)
            
            # Wait for the target chat to open
            contact_xpath = f"//span[@title='{target}']"
            contact_title = wait.until(EC.presence_of_element_located((By.XPATH, contact_xpath)))
            contact_title.click()
            time.sleep(3)

            # Locate message box and send message
            message_box_xpath = "//div[@contenteditable='true' and @data-tab='10']"
            message_box = wait.until(EC.presence_of_element_located((By.XPATH, message_box_xpath)))
            message_box.send_keys(message)
            message_box.send_keys(Keys.ENTER)
            time.sleep(3)
            
            # Confirm message is sent by checking for the checkmark or double checkmarks
            # Adjust the XPath based on the WhatsApp Web structure if needed
            sent_checkmark_xpath = "//span[contains(@aria-label, 'sent') or contains(@aria-label, 'delivered') or contains(@aria-label, 'read')]"
            wait.until(EC.presence_of_element_located((By.XPATH, sent_checkmark_xpath)))
            time.sleep(2)

        except Exception as e:
            print(f"Failed to send message to '{target}': {str(e)}")

    # Close the webdriver session
    driver.quit()
    messagebox.showinfo("Success", "Messages sent successfully")

# Create the main window
root = tk.Tk()
root.title("WhatsApp Message Sender")

# Create a text area for the message
text_area = tk.Text(root, height=10, width=50)
text_area.pack(pady=10)

# Create a button to send the message
send_button = tk.Button(root, text="Send Message", command=send_whatsapp_message)
send_button.pack(pady=10)

# Run the GUI event loop
root.mainloop()